import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:kida_dogs2/app/user/user_page.dart';
import 'package:kida_dogs2/main.dart';

class SecondPage extends StatefulWidget {
  const SecondPage({
    Key? key,
  }) : super(key: key);

  @override
  State<SecondPage> createState() => _SecondPageState();
}

class _SecondPageState extends State<SecondPage> {
  bool isLoggingIn = true;

  void toggleLoginRegistration() {
    setState(() {
      isLoggingIn = !isLoggingIn;
    });
  }

  @override
  Widget build(BuildContext context) {
    final title = isLoggingIn ? 'Logowanie' : 'Rejestracja';
    return Scaffold(
      appBar: AppBar(
          leading: IconButton(
              icon: const Icon(Icons.arrow_back),
              color: const Color.fromARGB(255, 1, 16, 91),
              onPressed: () {
                toggleLoginRegistration;
                Navigator.of(context)
                    .push(MaterialPageRoute(builder: (_) => const FirstPage()));
              }),
          title: Text(
            isLoggingIn ? 'Logowanie' : 'Rejestracja',
            style: GoogleFonts.calistoga(
              textStyle: const TextStyle(
                  color: Color.fromARGB(255, 1, 16, 91), fontSize: 20),
            ),
          )),
      body: const LoginPage(
isLoggingIn

      ),
    );
  }
}

class LoginPage extends StatelessWidget {
  const LoginPage({ required
isLoggingIn,

    super.key,
  });
bool isLoggingIn;
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context, snapshot) {
          final user = snapshot.data;
          if (user == null) {
            return UserPage();
          }
          return HomePage(user: user);
        });
  }
}

class HomePage extends StatelessWidget {
  const HomePage({
    super.key,
    required this.user,
  });

  final User user;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text('Jesteś zalogowany jako ${user.email}'),
          const SizedBox(
            height: 40,
          ),
          ElevatedButton(
              onPressed: () {
                FirebaseAuth.instance.signOut();
              },
              child: const Text('Wyloguj'))
        ],
      ),
    );
  }
}
